Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.o: \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h ../Core/Inc/main.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h \
 ../Core/Inc/stm32f1xx_hal_conf.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h \
 ../Drivers/CMSIS/Include/core_cm3.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_i2c.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_spi.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim_ex.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Core/Inc/main.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h:
../Core/Inc/stm32f1xx_hal_conf.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h:
../Drivers/CMSIS/Include/core_cm3.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_i2c.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_spi.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_tim_ex.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
